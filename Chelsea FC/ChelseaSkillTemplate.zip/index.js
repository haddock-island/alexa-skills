'use strict';
var Alexa = require('alexa-sdk');

var APP_ID = undefined; //OPTIONAL: replace with "amzn1.echo-sdk-ams.app.[your-unique-value-here]";
var SKILL_NAME = 'Space Facts';

/**
 * Array containing space facts.
 */
var FACTS = [
    "Chelsea football club is one of the 20 clubs that play in the English Premier League.",
    "Chelsea Football Club is an English professional football club based in Fulham, London, that competes in the Premier League. Founded in 1905, the club's home ground since then has been Stamford Bridge.",
    "Chelsea Football Club is nicknamed The Blues or The Pensioners",
    "Chelsea Football Club's owner is Roman Abramovich and Chairman is Bruce Buck",
    "In 2016, Chelsea Football Club were ranked by Forbes magazine as the seventh most valuable football club in the world, at £1.15 billion ($1.66 billion)",
    "Chelsea Football Club have only had one home ground, Stamford Bridge, where they have played since the team's foundation. It was officially opened on 28 April 1877",
    "Chelsea Football Club won their first Premier League Title in the year 1954-55. ",
    "Chelsea Football Club won their first UEFA Champions league Title in the year 2011-12.",
    "Chelsea Football Club won their first UEFA Europa league Title in the year 2012-13.",
    "Chelsea had their first major success in 1955, when they won the league championship. They then won various cup competitions between 1965 and 1996. The club's greatest period of success has come during the last two decades; winning 21 trophies since 1997.",
    "Chelsea's regular kit colours are royal blue shirts and shorts with white socks. The club's crest has been changed several times in attempts to re-brand the club and modernise its image. The current crest, featuring a ceremonial lion rampant regardant holding a staff, is a modification of the one introduced in the early 1950s",
];

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('GetFact');
    },
    'GetNewFactIntent': function () {
        this.emit('GetFact');
    },
    'GetFact': function () {
        // Get a random chelsea FC fact from the space facts list
        var factIndex = Math.floor(Math.random() * FACTS.length);
        var randomFact = FACTS[factIndex];
                
        // Create speech output
        var speechOutput = "Here's your fact: " + randomFact;

        this.emit(':tellWithCard', speechOutput, SKILL_NAME, randomFact)
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = "You can say tell me a fact about Chelsea football club, or, you can say exit... What can I help you with?";
        var reprompt = "What can I help you with?";
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', 'Goodbye!');
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', 'Goodbye!');
    }
};